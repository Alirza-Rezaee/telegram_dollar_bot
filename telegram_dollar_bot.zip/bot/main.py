import os
from telegram import Update
from telegram.ext import Application, CommandHandler, CallbackContext
from dotenv import load_dotenv
import requests

load_dotenv()  # بارگذاری متغیرهای محیطی از فایل .env

TELEGRAM_BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN")
API_KEY = os.getenv("API_KEY")

# ذخیره chat_id کاربران در یک فایل
def save_chat_id(chat_id):
    bot_folder = os.path.join(os.path.dirname(__file__), "chat_ids.txt")
    # ذخیره chat_id در فایل
    with open(bot_folder, "a") as f:
        f.write(f"{chat_id}\n")

# دستور start که زمانی که کاربر ربات را استارت می‌کند اجرا می‌شود
async def start(update: Update, context: CallbackContext):
    user_chat_id = update.message.chat_id
    save_chat_id(user_chat_id)
    await update.message.reply_text("سلام! من ربات قیمت دلار هستم. قیمت دلار را برایتان ارسال خواهم کرد.")

# دریافت قیمت دلار از API
def get_dollar_price():
    url = f"http://api.navasan.tech/latest/?api_key={API_KEY}"
    response = requests.get(url)
    data = response.json()
    dollar_buy_price = data["harat_naghdi_buy"]["value"]
    return dollar_buy_price

# ارسال قیمت دلار به یک کاربر
async def send_price_to_user(context: CallbackContext, chat_id: str):
    dollar_price = get_dollar_price()
    await context.bot.send_message(chat_id=chat_id, text=f"قیمت دلار: {dollar_price} ریال")

# تنظیمات و راه‌اندازی ربات
async def main():
    application = Application.builder().token(TELEGRAM_BOT_TOKEN).build()

    # اضافه کردن دستور start
    application.add_handler(CommandHandler("start", start))

    # مسیر فایل chat_ids.txt
    chat_ids_file_path = os.path.join(os.path.dirname(__file__), "chat_ids.txt")
    
    # بررسی و ایجاد فایل chat_ids.txt اگر وجود ندارد
    if not os.path.exists(chat_ids_file_path):
        with open(chat_ids_file_path, "w") as f:
            pass  # ایجاد فایل خالی اگر وجود نداشت

    # دریافت chat_id از فایل و ارسال قیمت
    with open(chat_ids_file_path, "r") as f:
        chat_ids = f.readlines()

    for chat_id in chat_ids:
        chat_id = chat_id.strip()
        # ارسال قیمت دلار به هر کاربر
        await send_price_to_user(application, chat_id)

    # شروع ربات بدون نیاز به استفاده از asyncio.run
    await application.run_polling()

if __name__ == '__main__':
    import asyncio
    # اجرای تابع اصلی بدون استفاده از asyncio.run
    asyncio.get_event_loop().create_task(main())
    asyncio.get_event_loop().run_forever()
